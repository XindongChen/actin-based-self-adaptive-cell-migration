﻿#!/usr/bin/python

###################################################### Mechanical Sensation and Self-regulated Actin-based Cell Motility Model ###########################################################

from numpy import*
import random
import numpy as np
from sympy import *
import os
import re
import math
import xlwt



xls = xlwt.Workbook()
sheet = xls.add_sheet('Outputsdata',cell_overwrite_ok=True)
excel_savepath='X:\Maaip\Outputs\Case3000'

extracellular_matrix_energy = 2e-18
energy_barrier = 1e-18
growth_time = 3000
critical_energy = extracellular_matrix_energy + energy_barrier
step_size = 6
critical_meancurvature = 3


############ Displacement/L0, P/(EI/L0^2), U/(EI/L0) and beta ##################################################################
elas_modul_fl = 2.0*1.0e9 # elastic modulus of flament is assmed 1GPa
diameter_fl = 7*1e-9   # the diameter of filaments is 7nm
moment_inertia = math.pi*(diameter_fl**4)/64  # the cross-sectional moment inertia for a circular cross-section is I = pi*d**4/64
flextural_rigidity = elas_modul_fl*moment_inertia  # the flextural rigidity EI of a cross section is k = EI
arps_range = [3, 4, 5, 6, 7, 8]
#darps = [300, 150, 100, 80, 50]
darps = [300, 150, 100, 100, 100]

alpha_pn = 0.12
euler_number = 2.718
critical_zero_number = 36
fluctuate_time_begin = 800
fluctuate_time_end = 2000
membrane_tension_force = 2*0.3e-9
extracellular_resistance = 0.6e-9
magnify_factor = 2
molecularclk_rupture_force = 0.3e-9
free_end_distance_critvalue = 10

height_lamelip = 150
plane_inclined_angle = 60  # this angle is very import for the planes that which is attached by filament
y_leading_edge_start_time0 = 40 # the start y coodinate of the low inclined plane and the up inclined plane
y_leading_edge_start = y_leading_edge_start_time0
height_central_plane = 30 # the height of the central vertical plane
planes = ['low_plane', 'central_plane', 'up_plane']
y_low_start = 0 # the low boudary for generating the start y coordiante of mother filaments
y_up_start = 20 # the up boudary for generating the start y coordiante of mother filaments
growth_rate = 2.5  # the growth rate every 5ms: the growth rate of filaments is 1nm/ms(1um/s)-PNAS-2010-Two competeing orientation

num_motherfilaments = 200
mean_filamentlength = 180
filamentlength_std_deviation = 30
larp = 10
arp_generate_section = 100
l_densityarp1 = 100
l_densityarp2 = 100
l_densityarp3 = 100

xy_angle_mu = 35
xy_angle_std_deviation = 5
reduced_xyangle =75
z_mu = height_lamelip/2
z_std_deviation = 50
z_mo_max_angle = 10
xy_arpangle = 90
z_arpangle = 10

def E0_Parameters_Planes (y_leading_edge_start):
	z_min_low_plane = 0
	z_max_low_plane = height_lamelip/2 - height_central_plane/2
	z_min_central_plane = z_max_low_plane
	z_max_central_plane = z_max_low_plane + height_central_plane
	y_central_plane = y_leading_edge_start + z_max_low_plane/tan(radians(plane_inclined_angle)) # the y coodinate of the central vertical plane
	z_min_up_plane = z_max_central_plane
	z_max_up_plane = height_lamelip
	normal_vect_low_plane = [0, tan(radians(plane_inclined_angle)), -1]
	normal_vect_central_plane = [0, 1, 0]
	normal_vect_up_plane = [0, tan(radians(plane_inclined_angle)), 1]
	point_low_plane = [0, y_leading_edge_start, 0]
	point_central_plane = [0, y_central_plane, z_max_low_plane]
	point_up_plane = [0,y_central_plane, z_max_central_plane]
	return z_min_low_plane, z_max_low_plane, z_min_central_plane, z_max_central_plane, y_central_plane, z_min_up_plane, z_max_up_plane, normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane, point_low_plane, point_central_plane, point_up_plane

def E1_NormalVector_Planes ():
	normal_vect_planes = [normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane]
	point_planes = [point_low_plane, point_central_plane, point_up_plane]
	normalvectdic_planes = {}
	pointdic_planes = {}
	i = 0
	for label in planes:
		normalvectdic_planes[label] = normal_vect_planes[i]
		pointdic_planes[label] = point_planes[i]
		i+=1
	return normalvectdic_planes, pointdic_planes

############################## To Import Data Pools  ##################################################################
f = open('sita01_89_dleb0')
sita01_89_dleb0=f.read()
sita01_89_dleb0=eval(sita01_89_dleb0) # eval function is used to transform str in to list form

def E2_Make_Datadic_sita01_89 ():
	sita01to89_len0025to3000_load003to3_dleb0_dic = {}
	for sitai in range(len(sita01_89_dleb0)):
		sita = sitai+1
		len0025to3000_load003to3_dleb0_dic = {}
		for lenj in range(len(sita01_89_dleb0[sitai])):
			len_true = (lenj+1)*growth_rate
			load003to3_dleb0_dic = {}
			for loadk in range(len(sita01_89_dleb0[sitai][lenj])):
				load_nondimen = round((loadk+1)*0.03*100)/100
				load003to3_dleb0_dic[load_nondimen] = sita01_89_dleb0[sitai][lenj][loadk]
			len0025to3000_load003to3_dleb0_dic[len_true] = load003to3_dleb0_dic
		sita01to89_len0025to3000_load003to3_dleb0_dic[sita]=len0025to3000_load003to3_dleb0_dic
	return sita01to89_len0025to3000_load003to3_dleb0_dic

"""
file1=open('sita01to89-len0025to3000-load003to3-dleb0-dic','w')
file1.write(str(sita01to89_len0025to3000_load003to3_dleb0_dic));
file1.close()
"""


f = open('sita01_89_cds') # there are 9 points to divide every filament into 10 segments
sita01_89_cds=f.read()
sita01_89_cds=eval(sita01_89_cds)

def E3_Make_Datadic_sita01_89cds ():
	sita01to89_len0025to3000_load003to3_b0bxy01to09_dic = {}
	for sitai in range(len(sita01_89_cds)):
		sita = sitai+1
		len0025to3000_load003to3_b0bxy01to09_dic = {}
		for lenj in range(len(sita01_89_cds[sitai])):
			len_true = (lenj+1)*growth_rate
			load003to3_b0bxy01to09_dic = {}
			for loadk in range(len(sita01_89_cds[sitai][lenj])):
				load_nondimen = round((loadk+1)*0.03*100)/100
				load003to3_b0bxy01to09_dic[load_nondimen] = sita01_89_cds[sitai][lenj][loadk]
			len0025to3000_load003to3_b0bxy01to09_dic[len_true] = load003to3_b0bxy01to09_dic
		sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita]=len0025to3000_load003to3_b0bxy01to09_dic
	return sita01to89_len0025to3000_load003to3_b0bxy01to09_dic


"""
file2=open('sita01to89-len0025to3000-load003to3-b0bxy01to09-dic','w')
file2.write(str(sita01to89_len0025to3000_load003to3_b0bxy01to09_dic));
file2.close()
"""


############ The generation of the model against time ##################################################################

def E4_Generate_Motherfilament (num_motherfilaments, mean_filamentlength, filamentlength_std_deviation, height_lamelip, y_low_start, y_up_start, xy_angle_mu, xy_angle_std_deviation, z_mu, z_std_deviation, z_mo_max_angle):
	xmostart1 = []  # to generate start x coordinates of the mother filament
	ymostart1 = []  # to generate start y coordinates of the mother filament
	# this is to make the mother filament distribute uniformally in x direction
	num_squre_per_edge = 1
	num_mo_per_square = int(num_motherfilaments / num_squre_per_edge)
	num_motherfilaments = num_mo_per_square*num_squre_per_edge
	lx_square = 1000 / num_squre_per_edge
	for i in range(num_squre_per_edge):
		for j in range(num_mo_per_square):
			xrandomdata1 = random.uniform(i*lx_square, (i+1)*lx_square)
			xmostart1.append(xrandomdata1)
	for i in range(num_motherfilaments):
		yrandomdata1 = random.uniform(y_low_start, y_up_start)
		ymostart1.append(yrandomdata1)
	zmostartsample1 = []
	for i in range(2000):
		zstartrandomdata1 = random.gauss(z_mu, z_std_deviation)
		if 0 < zstartrandomdata1 < height_lamelip:
			zmostartsample1.append(zstartrandomdata1)
	zmostart1 = random.sample(zmostartsample1, len(xmostart1))
	lenmo1 = []
	for i in range(len(xmostart1)):
		lenrandomdata1 = int(random.gauss(mean_filamentlength, filamentlength_std_deviation))
		lenmo1.append(lenrandomdata1)
	zmoend1 = []
	zmoangles = []
	for i in range(len(xmostart1)):
		zmoangle = random.gauss(0, z_mo_max_angle)
		zendrandomdata1 = zmostart1[i] + lenmo1[i] * (math.sin(math.radians(zmoangle)))
		while zendrandomdata1 < 0 or height_lamelip < zendrandomdata1:
			zmoangle = random.gauss(0, z_mo_max_angle)
			zendrandomdata1 = zmostart1[i] + lenmo1[i] * (math.sin(math.radians(zmoangle)))
		else:
			zmoend1.append(zendrandomdata1)
			zmoangles.append(zmoangle)
	zhabs1 = []
	for i in range(len(xmostart1)):
		zhdifference1 = abs((zmoend1[i]) - (zmostart1[i]))
		zhabs1.append(zhdifference1)
	orimosampleplus1 = []
	for i in range(10000):
		orientationrandomdataplus1 = random.gauss(math.radians(xy_angle_mu), math.radians(xy_angle_std_deviation))
		if math.radians(180) >= orientationrandomdataplus1 >= 0:
			orimosampleplus1.append(orientationrandomdataplus1)
	orimosampleminus1 = []
	for i in range(10000):
		orientationrandomdataminus1 = random.gauss(math.radians(-xy_angle_mu), math.radians(xy_angle_std_deviation))
		if math.radians(-180) <= orientationrandomdataminus1 <= 0:
			orimosampleminus1.append(orientationrandomdataminus1)
	orimosample1 = orimosampleplus1 + orimosampleminus1
	random.shuffle(orimosample1)
	orimo1 = random.sample(orimosample1, len(xmostart1))
	zanglesabs1 = []
	for i in range(len(xmostart1)):
		zangleabs1 = math.asin((zhabs1[i]) / (lenmo1[i]))
		zanglesabs1.append(zangleabs1)
	lenmoinxy1 = []
	for i in range(len(xmostart1)):
		lenprojectedinxy1 = ((lenmo1[i]) * (math.cos(zanglesabs1[i])))
		lenmoinxy1.append(lenprojectedinxy1)
	xmoend1 = []
	ymoend1 = []
	for i in range(len(xmostart1)):
		xendpoint1 = ((xmostart1[i]) + (lenmoinxy1[i]) * math.sin(orimo1[i]))
		xmoend1.append(xendpoint1)
		yendpoint1 = ((ymostart1[i]) + (lenmoinxy1[i]) * math.cos(orimo1[i]))
		ymoend1.append(yendpoint1)
	return xmostart1, ymostart1, zmostart1, xmoend1, ymoend1, zmoend1, lenmo1


# To calculate mother filaments' vectors and their angles with respect to the x, y and z axes
def E5_Vector_Motherfilament (xfli_start, yfli_start, zfli_start, xfli_end, yfli_end, zfli_end):
	len_fli = ((xfli_end - xfli_start)**2 + (yfli_end - yfli_start)**2 + (zfli_end - zfli_start)**2)**0.5
	fli_len_timemax = len_fli
	xvector_fli = (xfli_end - xfli_start)
	xori_fli_cos = xvector_fli / len_fli
	yvector_fli = (yfli_end - yfli_start)
	yori_fli_cos = yvector_fli / len_fli
	zvector_fli = (zfli_end - zfli_start)
	zori_fli_cos = zvector_fli / len_fli
	return fli_len_timemax, len_fli, xvector_fli, xori_fli_cos, yvector_fli, yori_fli_cos, zvector_fli, zori_fli_cos


# To calculate the angle between mother filament and the normal vector of each leading edge plane
def E6_Angle_Filaments_PlanesNorvect ():
	sita_fli_planes_angles_dic = {} # the angle between mother filament and the normal vector of each leading edge plane
	for label in planes:
		normalvector_length_plane = (normalvectdic_planes[label][0] ** 2 + normalvectdic_planes[label][1] ** 2 + normalvectdic_planes[label][2] ** 2) ** 0.5
		sita_fli_plane_angle = (180/math.pi)*(math.acos((xvector_fli * normalvectdic_planes[label][0] + yvector_fli * normalvectdic_planes[label][1] + zvector_fli * normalvectdic_planes[label][2])/(normalvector_length_plane * len_fli)))
		sita_fli_planes_angles_dic[label]=sita_fli_plane_angle
	return sita_fli_planes_angles_dic


def E7_Angle_Yaxis_PlanesNorvect (): # the angle between the normal vector of the plane and the y axis, namely the vector (0, 1, 0)
	angle_yaxis_planesnormal_dic = {}
	for label in planes:
		normalvector_length_plane = (normalvectdic_planes[label][0] ** 2 + normalvectdic_planes[label][1] ** 2 + normalvectdic_planes[label][2] ** 2) ** 0.5
		angle_yaxis_planenormal = (180/math.pi)*(math.acos((0 * normalvectdic_planes[label][0] + 1 * normalvectdic_planes[label][1] + 0 * normalvectdic_planes[label][2])/(normalvector_length_plane * 1)))
		angle_yaxis_planesnormal_dic[label]=angle_yaxis_planenormal
	return angle_yaxis_planesnormal_dic


# To calculate the perpendicular distance from the start point of mother filament to the each leading edge plane
def E8_PerpDist_Filament_Planes ():
	perpdistdic_fli_planes_dic = {}
	for label in planes:
		a_coef = normalvectdic_planes[label][0] # in order to obatin the equation of the leading edge plane
		b_coef = normalvectdic_planes[label][1]
		c_coef = normalvectdic_planes[label][2]
		d_coef = -(a_coef * pointdic_planes[label][0] + b_coef * pointdic_planes[label][1] + c_coef * pointdic_planes[label][2])
		fli_plane_perpendicular_distance = abs(a_coef * xfli_start + b_coef * yfli_start + c_coef * zfli_start + d_coef)/((a_coef ** 2 + b_coef ** 2 + c_coef ** 2)**0.5)
		perpdistdic_fli_planes_dic[label] = fli_plane_perpendicular_distance
	return perpdistdic_fli_planes_dic


def E9_Attach_Filament_Plane ():
	dist_fli_corespond_plane_dic = {}
	normal_vector_corespond_plane_dic = {}
	perpdists_fli_planes_dic = {}
	for label in planes:
		perpdist_fli_plane = perpdistdic_fli_planes_dic[label]
		perpdists_fli_planes_dic[perpdist_fli_plane] = label
	order_tuple = sorted(zip(perpdists_fli_planes_dic.keys(), perpdists_fli_planes_dic.values()))
	shoutest_perpdist = order_tuple[0][0]
	shortest_perpdist_plane = order_tuple[0][1]
	dist_fli_corespond_plane_dic[shoutest_perpdist] = shortest_perpdist_plane
	normal_vector_corespond_plane_dic[shortest_perpdist_plane]=normalvectdic_planes[shortest_perpdist_plane]
	return dist_fli_corespond_plane_dic, shortest_perpdist_plane, normal_vector_corespond_plane_dic


def E10_Fli_Angle_Dist_Corespplane ():
	for corespplane in dist_fli_corespond_plane_dic.values():
		fli_corespplane = corespplane
	sita_fli_planej_angle = sita_fli_planes_angles_dic[fli_corespplane]
	angle_yaxis_planenormal = angle_yaxis_planesnormal_dic[fli_corespplane]
	if sita_fli_planej_angle >= 89:
		sita_fli_planej_angle = 89
	else:
		sita_fli_planej_angle = int(sita_fli_planej_angle + 1)
	for key in dist_fli_corespond_plane_dic.keys():
		fli_len_timeplane = round(key/math.cos(math.radians(sita_fli_planej_angle))/growth_rate)*growth_rate
	return fli_corespplane, sita_fli_planej_angle, fli_len_timeplane, angle_yaxis_planenormal


def E11_Pointattach_Filament_Plane ():
	x_fli_plane_end = xfli_start + fli_len_timeplane * xori_fli_cos
	y_fli_plane_end = yfli_start + fli_len_timeplane * yori_fli_cos
	z_fli_plane_end = zfli_start + fli_len_timeplane * zori_fli_cos
	xyz_fli_plane_end = [x_fli_plane_end, y_fli_plane_end, z_fli_plane_end]
	return x_fli_plane_end, y_fli_plane_end, z_fli_plane_end, xyz_fli_plane_end


def E12_Critical_Length ():
	i=0
	loads_corresp = []
	for key in sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle].keys():
		beta0_difs = []
		for load in sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][key]:
			beta0_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][key][load][3] - 90)
			beta0_difs.append(beta0_dif)
		load_corresp = round(( beta0_difs.index(min(beta0_difs))+1)*0.03*100)/100
		loads_corresp.append(load_corresp)
	deltad_difs = []
	i = 0
	lp = fli_len_timeplane
	for key in sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle].keys():
		j = loads_corresp[i]
		deltad = (1-lp/key)*math.cos(math.radians(sita_fli_planej_angle))
		deltad_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][key][j][0] - deltad)
		deltad_difs.append(deltad_dif)
		i+=1
	len_critical = round(deltad_difs.index(min(deltad_difs))+1)*growth_rate
	return len_critical


def E13_Load_Energy_Curvature_Length (ii): #fli_t is the time that the ith filament growth; fli_len_time, fli_len_timeplane and fli_len_timemax denote the ith filament' length at its growth time t, its length for reaching the plane and its maximum length
	#print (fli_len_time)
	#print (fli_len_timeplane)
	#print (len_critical)
	#print (fli_len_timemax)
	if fli_len_timemax < fli_len_timeplane:
		fli_effective_len_time = fli_len_time
		load_corresp = 0
		p_load_time = 0
		pn_load_time = 0
		energy_fl_time = 0
		k_meancurvature_time = 0
		#print ('filament ' + str(ii+1) + 'th ' + 'maximum length cannot reach or has left the leading edge membrane, so it is unable to contact the membrane')
	else:
		if len_critical < fli_len_timemax:
			if fli_len_time <= fli_len_timeplane:
				fli_effective_len_time = fli_len_time
				load_corresp = 0
				p_load_time = 0
				pn_load_time = 0
				energy_fl_time = 0
				k_meancurvature_time = 0
				#print ('filament ' + str(ii+1) + 'th ' + 'can have both point and line contacts, but have not yet contact')
			elif fli_len_timeplane < fli_len_time < len_critical:
				fli_effective_len_time = fli_len_time
				deltad_fli_actual = (fli_effective_len_time - fli_len_timeplane) * math.cos(math.radians(sita_fli_planej_angle))
				deltad_fli = deltad_fli_actual / fli_effective_len_time
				deltad_fli_difs = []
				for loadk in range(len(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time])):
					load = round((loadk+1)*0.03*100)/100
					deltad_fli_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load][0] - deltad_fli)
					deltad_fli_difs.append(deltad_fli_dif)
				load_corresp = round((deltad_fli_difs.index(min(deltad_fli_difs))+1)*0.03*100)/100
				#print ('filament ' + str(ii+1) + 'th ' + 'can have both point and line contacts, but now it is point contact')
				p_load_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][1]*flextural_rigidity/((fli_effective_len_time*1e-9)**2)  ## to transfer load p'=p/(EI/L0^2), so p = p'*EI/L0^2, here the unit is nm
				pn_load_time = p_load_time * math.cos(math.radians(angle_yaxis_planenormal))
				energy_fl_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][2]*flextural_rigidity/(fli_effective_len_time*1e-9)  ## to transfer load U'=U/(EI/L0^2), so U = U'*EI/L0
				k_meancurvature_time = math.radians(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][3] - sita_fli_planej_angle)/(fli_effective_len_time*1e-3)  # the maximum curvature of filament at t. maximum curvature is at the fixed end 有效长度再生长是优问题的 这就是为什么会变小
				#print (fli_len_time)
				#print (sita_fli_planej_angle)
				#print (fli_effective_len_time)
				#print (load_corresp)
				#print (sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][0], 1000000000000)
			else: # len_critical < fli_len_time #
				fli_effective_len_time = len_critical
				beta0_fli_difs = []
				for loadk in range(len(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time])):
					load = round((loadk+1)*0.03*100)/100
					beta0_fli_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load][3] - 90)
					beta0_fli_difs.append(beta0_fli_dif)
				load_corresp = round((beta0_fli_difs.index(min(beta0_fli_difs))+1)*0.03*100)/100
				#print ('filament ' + str(ii+1) + 'th ' + 'can have both point and line contacts, but now it grows into line contact')
				p_load_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][1]*flextural_rigidity/((fli_effective_len_time*1e-9)**2)  ## to transfer load p'=p/(EI/L0^2), so p = p'*EI/L0^2, here the unit is nm
				pn_load_time = p_load_time * math.cos(math.radians(angle_yaxis_planenormal))
				energy_fl_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][2]*flextural_rigidity/(fli_effective_len_time*1e-9)  ## to transfer load U'=U/(EI/L0^2), so U = U'*EI/L0
				k_meancurvature_time = math.radians(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][3] - sita_fli_planej_angle)/(fli_effective_len_time*1e-3)  # the maximum curvature of filament at t. maximum curvature is at the fixed end 有效长度再生长是优问题的 这就是为什么会变小
				#print (fli_len_time)
				#print (sita_fli_planej_angle)
				#print (fli_effective_len_time)
				#print (load_corresp)
		else: # fli_len_timemax <= len_critical
			if fli_len_time <= fli_len_timeplane:
				fli_effective_len_time = fli_len_time
				load_corresp = 0
				p_load_time = 0
				pn_load_time = 0
				energy_fl_time = 0
				k_meancurvature_time = 0
				#print ('filament ' + str(ii+1) + 'th ' + 'only has point contact, but have not yet contact')
			elif fli_len_timeplane < fli_len_time < fli_len_timemax:
				fli_effective_len_time = fli_len_time
				deltad_fli_actual = (fli_effective_len_time - fli_len_timeplane) * math.cos(math.radians(sita_fli_planej_angle))
				deltad_fli = deltad_fli_actual / fli_effective_len_time
				deltad_fli_difs = []
				for loadk in range(len(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time])):
					load = round((loadk+1)*0.03*100)/100
					deltad_fli_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load][0] - deltad_fli)
					deltad_fli_difs.append(deltad_fli_dif)
				load_corresp = round((deltad_fli_difs.index(min(deltad_fli_difs))+1)*0.03*100)/100
				#print ('filament ' + str(ii+1) + 'th ' + 'only has point contact, and now it is point contact')
				p_load_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][1]*flextural_rigidity/((fli_effective_len_time*1e-9)**2)  ## to transfer load p'=p/(EI/L0^2), so p = p'*EI/L0^2, here the unit is nm
				pn_load_time = p_load_time * math.cos(math.radians(angle_yaxis_planenormal))
				energy_fl_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][2]*flextural_rigidity/(fli_effective_len_time*1e-9)  ## to transfer load U'=U/(EI/L0^2), so U = U'*EI/L0
				k_meancurvature_time = math.radians(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][3] - sita_fli_planej_angle)/(fli_effective_len_time*1e-3)  # the maximum curvature of filament at t. maximum curvature is at the fixed end 有效长度再生长是优问题的 这就是为什么会变小
				#print (fli_len_time)
				#print (sita_fli_planej_angle)
				#print (fli_effective_len_time)
				#print (load_corresp)
			else: # fli_len_timemax <= fli_len_time:
				fli_effective_len_time = int(fli_len_timemax/growth_rate)*growth_rate
				deltad_fli_actual = (fli_effective_len_time - fli_len_timeplane) * math.cos(math.radians(sita_fli_planej_angle))
				deltad_fli = deltad_fli_actual / fli_effective_len_time
				deltad_fli_difs = []
				#print('fli_effective_len_time:', fli_effective_len_time)
				for loadk in range(len(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time])):
					load = round((loadk+1)*0.03*100)/100
					deltad_fli_dif = abs(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load][0] - deltad_fli)
					deltad_fli_difs.append(deltad_fli_dif)
				load_corresp = round((deltad_fli_difs.index(min(deltad_fli_difs))+1)*0.03*100)/100
				#print ('filament ' + str(ii+1) + 'th ' + 'only has point contact, and now it reaches its maximum length')
				p_load_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][1]*flextural_rigidity/((fli_effective_len_time*1e-9)**2)  ## to transfer load p'=p/(EI/L0^2), so p = p'*EI/L0^2, here the unit is nm
				pn_load_time = p_load_time * math.cos(math.radians(angle_yaxis_planenormal))
				energy_fl_time = sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][2]*flextural_rigidity/(fli_effective_len_time*1e-9)  ## to transfer load U'=U/(EI/L0^2), so U = U'*EI/L0
				k_meancurvature_time = math.radians(sita01to89_len0025to3000_load003to3_dleb0_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][3] - sita_fli_planej_angle)/(fli_effective_len_time*1e-3)  # the maximum curvature of filament at t. maximum curvature is at the fixed end 有效长度再生长是优问题的 这就是为什么会变小
				#print (fli_len_time)
				#print (sita_fli_planej_angle)
				#print (fli_effective_len_time)
				#print (load_corresp)
	return p_load_time, pn_load_time, energy_fl_time, k_meancurvature_time, fli_effective_len_time, load_corresp

"""
def E14_zc1_ector_normal_plane(x1, y1, z1, x2, y2, z2, c1): # this function is to generate the normal verctor(a1, b1, c1) of the plane of the two intersected vector (x1, y1, z1) and (x2, y2, z2). 即 z轴vector(a1, b1, c1)
	a1 = (z2*y1-z1*y2)/(x1*y2-x2*y1)
	b1 = (z2*x1-z1*x2)/(x2*y1-x1*y2)
	return a1, b1

def E15_xa2_vector_normal_plane(x1, y1, z1, x2, y2, z2, a2): # this function is to generate the normal verctor(a2, b2, c2) of the plane of the two intersected vector (x1, y1, z1) and (x2, y2, z2). 即 x轴vector(a2, b2, c2)
	b2 = (x2*z1-x1*z2)/(y1*z2-y2*z1)
	c2 = (x2*y1-x1*y2)/(y2*z1-y1*z2)
	return b2, c2
"""

def E14_Coordinates_forArp (ith):
	ith_angle = 3 * ith + 1
	ith_xcoord_deformed_local = 3 * ith + 2
	ith_ycoord_deformed_local = 3 * ith + 3
	#print ('This is the ith point on filament',ith, sita_fli_planej_angle, fli_effective_len_time, load_corresp, k_meancurvature_time)
	kkk = ((9-ith)/10)*fli_effective_len_time*math.sin(math.radians(sita_fli_planej_angle))
	ooo = ((9-ith)/10)*fli_effective_len_time*math.cos(math.radians(sita_fli_planej_angle))
	#print (kkk, ooo)
	#print (sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_xcoord_deformed_local]*fli_effective_len_time, sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_ycoord_deformed_local]*fli_effective_len_time)
	x_deform_vector_in_new_coords = sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_xcoord_deformed_local]*fli_effective_len_time-((9-ith)/10)*fli_effective_len_time*math.sin(math.radians(sita_fli_planej_angle))
	y_deform_vector_in_new_coords = sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_ycoord_deformed_local]*fli_effective_len_time-((9-ith)/10)*fli_effective_len_time*math.cos(math.radians(sita_fli_planej_angle))
	len_deformvector_in_new_coords = (x_deform_vector_in_new_coords**2 + y_deform_vector_in_new_coords**2)**0.5 # this is the moving vector length of the end point between the undeformed state and the deformed state
	x1 = xvector_fli
	y1 = yvector_fli
	z1 = zvector_fli
	x2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][0]
	y2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][1]
	z2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][2]
	c1 = 1 # if z is negtive, does the condition changes????????????????????????????????????????????
	#这是求z轴的vector (a1, b1, c1)
	a1 = (z2*y1-z1*y2)/(x1*y2-x2*y1)
	b1 = (z2*x1-z1*x2)/(x2*y1-x1*y2)
	z_new_x = a1 # this is the projection of the new z-axis vector on the old x-axis
	z_new_y = b1 # this is the projection of the new z-axis vector on the old y-axis
	z_new_z = c1 # this is the projection of the new z-axis vector on the old z-axis
	y_new_x = normal_vector_corespond_plane_dic[shortest_perpdist_plane][0] # this is the projection of the new y-axis vector on the old x-axis
	y_new_y = normal_vector_corespond_plane_dic[shortest_perpdist_plane][1] # this is the projection of the new y-axis vector on the old y-axis
	y_new_z = normal_vector_corespond_plane_dic[shortest_perpdist_plane][2] # this is the projection of the new y-axis vector on the old z-axis
	x1 = a1
	y1 = b1
	z1 = c1
	x2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][0]
	y2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][1]
	z2 = normal_vector_corespond_plane_dic[shortest_perpdist_plane][2]
	a2 = 1
	#这是求x轴的vector (a2, b2, c2)
	b2 = (x2*z1-x1*z2)/(y1*z2-y2*z1)
	c2 = (x2*y1-x1*y2)/(y2*z1-y1*z2)
	x_new_x = a2 # this is the projection of the new x-axis vector on the old x-axis
	x_new_y = b2 # this is the projection of the new x-axis vector on the old y-axis
	x_new_z = c2 # this is the projection of the new x-axis vector on the old z-axis
	cos_belta_1new_1 = (x_new_x*1+x_new_y*0+x_new_z*0)/((x_new_x**2+x_new_y**2+x_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(1, 0, 0)
	cos_belta_1new_2 = (x_new_x*0+x_new_y*1+x_new_z*0)/((x_new_x**2+x_new_y**2+x_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 1, 0)
	cos_belta_1new_3 = (x_new_x*0+x_new_y*0+x_new_z*1)/((x_new_x**2+x_new_y**2+x_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 0, 1)
	cos_belta_2new_1 = (y_new_x*1+y_new_y*0+y_new_z*0)/((y_new_x**2+y_new_y**2+y_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(1, 0, 0)
	cos_belta_2new_2 = (y_new_x*0+y_new_y*1+y_new_z*0)/((y_new_x**2+y_new_y**2+y_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 1, 0)
	cos_belta_2new_3 = (y_new_x*0+y_new_y*0+y_new_z*1)/((y_new_x**2+y_new_y**2+y_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 0, 1)
	cos_belta_3new_1 = (z_new_x*1+z_new_y*0+z_new_z*0)/((z_new_x**2+z_new_y**2+z_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(1, 0, 0)
	cos_belta_3new_2 = (z_new_x*0+z_new_y*1+z_new_z*0)/((z_new_x**2+z_new_y**2+z_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 1, 0)
	cos_belta_3new_3 = (z_new_x*0+z_new_y*0+z_new_z*1)/((z_new_x**2+z_new_y**2+z_new_z**2)**0.5*1) # the cos angle between the new x-axis (x_new_x, x_new_y, x_new_z) and the old x-axis(0, 0, 1)
	coords_transform_new_to_old = np.array([[cos_belta_1new_1, cos_belta_2new_1, cos_belta_3new_1],[cos_belta_1new_2, cos_belta_2new_2, cos_belta_3new_2],[cos_belta_1new_3, cos_belta_2new_3, cos_belta_3new_3]]) # this is Jacobian Matrix
	deformed_vector_in_new_coords = np.array([[x_deform_vector_in_new_coords],[y_deform_vector_in_new_coords],[0]])
	deformed_vector_in_old_coords = np.dot(coords_transform_new_to_old, deformed_vector_in_new_coords)
	x_deformed_vector_in_old_coords = deformed_vector_in_old_coords[0][0]
	y_deformed_vector_in_old_coords = deformed_vector_in_old_coords[1][0]
	z_deformed_vector_in_old_coords = deformed_vector_in_old_coords[2][0]
	# the following is to make the deformation x,y and z vector in the right direction in the old coordinates system
	if xfli_start < xfli_end:
		x_deformed_vector_in_old_coords = abs(x_deformed_vector_in_old_coords)
	if xfli_end <= xfli_start:
		x_deformed_vector_in_old_coords = -abs(x_deformed_vector_in_old_coords)
	zaxis_xvector = 0
	zaxis_yvector = 0
	zaxis_zvector = 1
	len_zaxis_vector = (zaxis_xvector**2 + zaxis_yvector**2 + zaxis_zvector**2)**0.5
	x_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][0]
	y_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][1]
	z_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][2]
	len_plane_normal_vector = (x_plane_normal_vector**2 + y_plane_normal_vector**2 + z_plane_normal_vector**2)**0.5
	angle_planenormal_zaxis = math.acos((zaxis_xvector*x_plane_normal_vector + zaxis_yvector*y_plane_normal_vector + zaxis_zvector*z_plane_normal_vector)/(len_zaxis_vector*len_plane_normal_vector))*180/pi
	len_fli = (xvector_fli**2 + yvector_fli**2 + zvector_fli**2)**0.5
	angle_fli_zaxis = math.acos((zaxis_xvector*xvector_fli + zaxis_yvector*yvector_fli + zaxis_zvector*zvector_fli)/(len_zaxis_vector*len_fli))*180/pi
	if angle_planenormal_zaxis <= angle_fli_zaxis:
		z_deformed_vector_in_old_coords = -abs(z_deformed_vector_in_old_coords)
	if angle_fli_zaxis < angle_planenormal_zaxis:
		z_deformed_vector_in_old_coords = abs(z_deformed_vector_in_old_coords)
	y_deformed_vector_in_old_coords = -abs(y_deformed_vector_in_old_coords)
	# the above part is to make the deformation x,y and z vector in the right direction in the old coordinates system
	x_end = xfli_start + ((9-ith)/10) * fli_effective_len_time * xori_fli_cos
	y_end = yfli_start + ((9-ith)/10) * fli_effective_len_time * yori_fli_cos
	z_end = zfli_start + ((9-ith)/10) * fli_effective_len_time * zori_fli_cos
	x_arp_start =  x_end + x_deformed_vector_in_old_coords # after the deformation, the x coordinate of the daughter filament generating point
	y_arp_start =  y_end + y_deformed_vector_in_old_coords # after the deformation, the y coordinate of the daughter filament generating point
	z_arp_start =  z_end + z_deformed_vector_in_old_coords # after the deformation, the z coordinate of the daughter filament generating point
	xstart_daufli = x_arp_start
	ystart_daufli = y_arp_start
	zstart_daufli = z_arp_start
	if ystart_daufli < yfli_start or ystart_daufli > yfli_end:
		print ('the point selcted is not in the segment of filament, so the code has problems!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
		print (yfli_start, ystart_daufli, yfli_end)
	# angle_deformed = sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_angle]
	ith_angle = 3 * (ith-1) + 1
	ith_xcoord_deformed_local = 3 * (ith-1) + 2
	ith_ycoord_deformed_local = 3 * (ith-1) + 3
	x_deform_vector_in_new_coords = sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_xcoord_deformed_local]*fli_effective_len_time-((9-(ith-1))/10)*fli_effective_len_time*math.sin(math.radians(sita_fli_planej_angle))
	y_deform_vector_in_new_coords = sita01to89_len0025to3000_load003to3_b0bxy01to09_dic[sita_fli_planej_angle][fli_effective_len_time][load_corresp][ith_ycoord_deformed_local]*fli_effective_len_time-((9-(ith-1))/10)*fli_effective_len_time*math.cos(math.radians(sita_fli_planej_angle))
	deformed_vector_in_new_coords = np.array([[x_deform_vector_in_new_coords],[y_deform_vector_in_new_coords],[0]])
	coords_transform_new_to_old = np.array([[cos_belta_1new_1, cos_belta_2new_1, cos_belta_3new_1],[cos_belta_1new_2, cos_belta_2new_2, cos_belta_3new_2],[cos_belta_1new_3, cos_belta_2new_3, cos_belta_3new_3]]) # this is Jacobian Matrix
	deformed_vector_in_old_coords = np.dot(coords_transform_new_to_old, deformed_vector_in_new_coords)
	x_deformed_vector_in_old_coords = deformed_vector_in_old_coords[0][0]
	y_deformed_vector_in_old_coords = deformed_vector_in_old_coords[1][0]
	z_deformed_vector_in_old_coords = deformed_vector_in_old_coords[2][0]
	# the following is to make the deformation x,y and z vector in the right direction in the old coordinates system
	if xfli_start < xfli_end:
		x_deformed_vector_in_old_coords = abs(x_deformed_vector_in_old_coords)
	if xfli_end <= xfli_start:
		x_deformed_vector_in_old_coords = -abs(x_deformed_vector_in_old_coords)
	zaxis_xvector = 0
	zaxis_yvector = 0
	zaxis_zvector = 1
	len_zaxis_vector = (zaxis_xvector**2 + zaxis_yvector**2 + zaxis_zvector**2)**0.5
	x_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][0]
	y_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][1]
	z_plane_normal_vector = normal_vector_corespond_plane_dic[shortest_perpdist_plane][2]
	len_plane_normal_vector = (x_plane_normal_vector**2 + y_plane_normal_vector**2 + z_plane_normal_vector**2)**0.5
	angle_planenormal_zaxis = math.acos((zaxis_xvector*x_plane_normal_vector + zaxis_yvector*y_plane_normal_vector + zaxis_zvector*z_plane_normal_vector)/(len_zaxis_vector*len_plane_normal_vector))*180/pi
	len_fli = (xvector_fli**2 + yvector_fli**2 + zvector_fli**2)**0.5
	angle_fli_zaxis = math.acos((zaxis_xvector*xvector_fli + zaxis_yvector*yvector_fli + zaxis_zvector*zvector_fli)/(len_zaxis_vector*len_fli))*180/pi
	if angle_planenormal_zaxis <= angle_fli_zaxis:
		z_deformed_vector_in_old_coords = -abs(z_deformed_vector_in_old_coords)
	if angle_fli_zaxis < angle_planenormal_zaxis:
		z_deformed_vector_in_old_coords = abs(z_deformed_vector_in_old_coords)
	y_deformed_vector_in_old_coords = -abs(y_deformed_vector_in_old_coords)
	# the above part is to make the deformation x,y and z vector in the right direction in the old coordinates system
	x_end = xfli_start + ((9-(ith-1))/10) * fli_effective_len_time * xori_fli_cos
	y_end = yfli_start + ((9-(ith-1))/10) * fli_effective_len_time * yori_fli_cos
	z_end = zfli_start + ((9-(ith-1))/10) * fli_effective_len_time * zori_fli_cos
	x_next =  x_end + x_deformed_vector_in_old_coords # after the deformation, the x coordinate of the daughter filament generating point
	y_next =  y_end + y_deformed_vector_in_old_coords # after the deformation, the y coordinate of the daughter filament generating point
	z_next =  z_end + z_deformed_vector_in_old_coords # after the deformation, the z coordinate of the daughter filament generating point
	# This is the vector of the selected segement on mother filament after deformation
	x_vector_mo_afdeformed = x_next - xstart_daufli # This is the x vector of the mother filament segment after deformation
	y_vector_mo_afdeformed = y_next - ystart_daufli # This is the y vector of the mother filament segment after deformation
	z_vector_mo_afdeformed = z_next - zstart_daufli # This is the z vector of the mother filament segment after deformation
	len_segment = (x_vector_mo_afdeformed**2 + y_vector_mo_afdeformed**2 + z_vector_mo_afdeformed**2)**0.5
	z_angle_segment = math.asin(z_vector_mo_afdeformed/len_segment)
	x_angle_segment = math.asin(x_vector_mo_afdeformed/len_segment)*180/np.pi
	z_angle_min_daufli = z_angle_segment - math.radians(70)
	z_angle_max_daufli = z_angle_segment + math.radians(70)
	len_daufli = int(random.gauss(mean_filamentlength, filamentlength_std_deviation))
	deltaz_min_daufli = len_daufli*math.sin(z_angle_min_daufli)
	deltaz_max_daufli = len_daufli*math.sin(z_angle_max_daufli)
	zend_min_daufli = zstart_daufli + deltaz_min_daufli
	zend_max_daufli = zstart_daufli + deltaz_max_daufli
	if zend_min_daufli < 0:
		zend_min_daufli = 0
	if zend_max_daufli > height_lamelip:
		zend_max_daufli = height_lamelip
	zend_daufli = random.uniform(zend_min_daufli, zend_max_daufli)
	deltaz_daufli = abs(zend_daufli - zstart_daufli)
	deltaz_daufli_standard = len_daufli*math.sin(z_arpangle*pi/180)
	circle_num = 0
	while deltaz_daufli > deltaz_daufli_standard and circle_num < 1000:
		zend_daufli = random.uniform(zend_min_daufli, zend_max_daufli)
		deltaz_daufli = abs(zend_daufli - zstart_daufli)
		deltaz_daufli_standard = len_daufli*math.sin(z_arpangle*pi/180)
		circle_num+=1
	a_parameter = ((x_next - xstart_daufli)**2) + ((y_next - ystart_daufli)**2)
	b_parameter = (-2)*(len_segment*len_daufli*math.cos(math.radians(70)) - ((z_next - zstart_daufli)*(zend_daufli - zstart_daufli)))*(x_next - xstart_daufli)
	c_parameter = ((len_segment*len_daufli*math.cos(math.radians(70)) - ((z_next - zstart_daufli)*(zend_daufli - zstart_daufli)))**2) - (((len_daufli)**2)-((zend_daufli - zstart_daufli)**2))*((y_next - ystart_daufli)**2)
	x_daufli_endsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xstart_daufli
	x_daufli_endbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xstart_daufli
	x_daufli_endsmall_big = [x_daufli_endsmall, x_daufli_endbig]
	xend_daufli = random.choice(x_daufli_endsmall_big)
	a =len_segment*len_daufli*math.cos(math.radians(70))
	b = xend_daufli - xstart_daufli
	c = x_next - xstart_daufli
	if c >= 0:
		x_small_daufli = xend_daufli
		x_big_daufli = xstart_daufli
	else: #c < 0
		x_small_daufli = xstart_daufli
		x_big_daufli = xend_daufli
	d = zend_daufli - zstart_daufli
	e = z_next - zstart_daufli
	g = y_next - ystart_daufli
	f = (a - b*c - d*e)/g
	h = abs(b/f) # tan(delta_x/delta_y)
	count_num = 0
	while (x_small_daufli > x_big_daufli or f < 0) and count_num < 100:
		zend_daufli = random.uniform(zend_min_daufli, zend_max_daufli)
		deltaz_daufli = abs(zend_daufli - zstart_daufli)
		deltaz_daufli_standard = len_daufli*math.sin(z_arpangle*pi/180)
		circle_num=0
		while deltaz_daufli > deltaz_daufli_standard and circle_num <1000:
			zend_daufli = random.uniform(zend_min_daufli, zend_max_daufli)
			deltaz_daufli = abs(zend_daufli - zstart_daufli)
			deltaz_daufli_standard = len_daufli*math.sin(z_arpangle*pi/180)
			circle_num+=1
		a_parameter = ((x_next - xstart_daufli)**2) + ((y_next - ystart_daufli)**2)
		b_parameter = (-2)*(len_segment*len_daufli*math.cos(math.radians(70)) - ((z_next - zstart_daufli)*(zend_daufli - zstart_daufli)))*(x_next - xstart_daufli)
		c_parameter = ((len_segment*len_daufli*math.cos(math.radians(70)) - ((z_next - zstart_daufli)*(zend_daufli - zstart_daufli)))**2) - (((len_daufli)**2)-((zend_daufli - zstart_daufli)**2))*((y_next - ystart_daufli)**2)
		x_daufli_endsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xstart_daufli
		x_daufli_endbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xstart_daufli
		x_daufli_endsmall_big = [x_daufli_endsmall, x_daufli_endbig]
		xend_daufli = random.choice(x_daufli_endsmall_big)
		a =len_segment*len_daufli*math.cos(math.radians(70))
		b = xend_daufli - xstart_daufli
		c = x_next - xstart_daufli
		if c >= 0:
			x_small_daufli = xend_daufli
			x_big_daufli = xstart_daufli
		else: #c < 0
			x_small_daufli = xstart_daufli
			x_big_daufli = xend_daufli
		d = zend_daufli - zstart_daufli
		e = z_next - zstart_daufli
		g = y_next - ystart_daufli
		f = (a - b*c - d*e)/g
		h = abs(b/f)
		count_num+=1
	deltaz_daufli = zend_daufli - zstart_daufli
	yend_daufli = ((len_segment*len_daufli*math.cos(math.radians(70)) - ((z_next - zstart_daufli)*(deltaz_daufli)))-(x_next - xstart_daufli)*(xend_daufli - xstart_daufli))/(y_next - ystart_daufli)+ystart_daufli
	xvector_daufli = xend_daufli - xstart_daufli
	yvector_daufli = yend_daufli - ystart_daufli
	zvector_daufli = zend_daufli - zstart_daufli
	branch_angle_arp = math.acos((xvector_daufli*x_vector_mo_afdeformed + yvector_daufli*y_vector_mo_afdeformed + zvector_daufli*z_vector_mo_afdeformed)/(len_segment*len_daufli))*180/(np.pi)
	z_angle_daufli = math.asin(zvector_daufli/len_daufli)*180/(np.pi)
	x_angle_daufli = math.asin(xvector_daufli/len_daufli)*180/(np.pi)
	#print ('000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')
	#print (branch_angle_arp)
	#print (z_angle_daufli)
	#print (x_angle_daufli)
	#print (x_angle_segment)
	#print (count_num, circle_num)
	return xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli


curvature_darp_dic = {0.1: 200, 1: 100, 3: 70, 4: 50}
def E15_Arp_Generation (ts_fli_s_dic,ts_miss_fli_s_dic, nst_fli_numarp_dic, nst_fli_numarp_coords_dic, nst_fli_arps_iths_dic):
	#print ('this is ith filament......................................................................................................................................................................................................')
	#print (ii+1)
	if k_meancurvature_time == 0:
		num_arp = nst_fli_numarp_dic[ii+1]
		numarp_coords = nst_fli_numarp_coords_dic[ii+1]
		numarp_iths = nst_fli_arps_iths_dic[ii+1]
		nst_fli_numarp_dic[ii+1] = num_arp
		nst_fli_numarp_coords_dic[ii+1] = numarp_coords
		nst_fli_arps_iths_dic[ii+1] = numarp_iths
	else: #k_meancurvature_time > 0:
		if 0 < k_meancurvature_time < 0.3:
			darp = darps[0]
		elif 0.3 <= k_meancurvature_time < 1:
			darp = darps[1]
		elif 1 <= k_meancurvature_time < 3:
			darp = darps[2]
		elif 3 <= k_meancurvature_time < 4:
			darp = darps[3]
		else:
			darp = darps[4]
		num_arp = int(fli_effective_len_time/darp - 1)
		if num_arp <= 0:
			num_arp = 0
		if num_arp <= nst_fli_numarp_dic[ii+1]:
			num_arp = nst_fli_numarp_dic[ii+1]
			num_arp_iths = nst_fli_arps_iths_dic[ii+1]
			#print ('the ith arps on the filament', ii+1, num_arp_iths)
			#points_range = [2, 3, 4, 5, 6, 7, 8]
			#points_selected = random.sample(points_range, num_arp)
			points_selected = num_arp_iths
			points_selected.sort()
			points_selected.reverse()
			arp_num_count = 0
			numarp_coords = []
			replaces_jj = []
			xstart_daufli_replaces = []
			ystart_daufli_replaces = []
			zstart_daufli_replaces = []
			xend_daufli_replaces = []
			yend_daufli_replaces = []
			zend_daufli_replaces = []
			iths = []
			dddd = 0
			for ith in points_selected:
				arp_num_count+=1
				xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli = E14_Coordinates_forArp (ith)
				for jj in range(len(xfli_starts)):
					#print (nst_fli_numarp_coords_dic[ii+1],'hello')
					#print (nst_fli_arps_iths_dic[ii+1],'hello')
					#print (nst_fli_numarp_dic[ii+1],'hello')
					#print (num_arp, 'hello')
					#print (arp_num_count, ith,'hello')
					xxx = 6*(arp_num_count-1)+0
					#print (xxx, dddd, 'hello')
					#print (nst_fli_numarp_coords_dic[ii+1][xxx],'hello')
					#print (nst_fli_arps_iths_dic[ii+1][xxx],'hello')
					#print (numarp_coords)
					#print ('jj', len(xfli_starts), xxx, len(nst_fli_numarp_coords_dic[ii+1]))
					#print ('jj:', jj, len(xfli_starts), len(xfli_ends))
					#print (xfli_starts[jj])
					#print (xfli_ends[jj])
					#print ('xxx', xxx, len(nst_fli_numarp_coords_dic[ii+1]))
					#print (nst_fli_numarp_coords_dic[ii+1][xxx])
					#print (nst_fli_numarp_coords_dic[ii+1][xxx+3])
					if (xfli_starts[jj] - nst_fli_numarp_coords_dic[ii+1][xxx]) == 0 and (xfli_ends[jj] - nst_fli_numarp_coords_dic[ii+1][xxx+3]) == 0:
						dddd+=1
						replace_jj = jj
						replaces_jj.append(replace_jj)
						xstart_daufli_replaces.append(xstart_daufli)
						ystart_daufli_replaces.append(ystart_daufli)
						zstart_daufli_replaces.append(zstart_daufli)
						xend_daufli_replaces.append(xend_daufli)
						yend_daufli_replaces.append(yend_daufli)
						zend_daufli_replaces.append(zend_daufli)
						iths.append(ith)
						numarp_coords = numarp_coords + [xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli]
			circle_replace=0
			for kk in replaces_jj:
				xfli_starts[kk] = xstart_daufli_replaces[circle_replace]
				yfli_starts[kk] = ystart_daufli_replaces[circle_replace]
				zfli_starts[kk] = zstart_daufli_replaces[circle_replace]
				xfli_ends[kk] = xend_daufli_replaces[circle_replace]
				yfli_ends[kk] = yend_daufli_replaces[circle_replace]
				zfli_ends[kk] = zend_daufli_replaces[circle_replace]
				circle_replace+=1
			nst_fli_numarp_dic[ii+1] = num_arp
			nst_fli_numarp_coords_dic[ii+1] = numarp_coords
			nst_fli_arps_iths_dic[ii+1] = num_arp_iths
			#print ('big circle',iths, nst_fli_numarp_dic[ii+1], nst_fli_numarp_coords_dic[ii+1])
			#print ('points_selected =',points_selected, arp_num_count)
			if num_arp != (len(numarp_coords)/6):
				print ('wrong111111111')
				#xfli_starts.sort()
				#yfli_starts.sort()
				#zfli_starts.sort()
				#print (xfli_starts)
				#print (yfli_starts)
				#print (zfli_starts)
				quit()#   exit()
		else: # num_arp >= nst_fli_numarp_dic[ii+1]
			num_arp_net = num_arp - len(nst_fli_arps_iths_dic[ii+1])
			points_range = arps_range
			points_selected_net = random.sample(points_range, num_arp_net)
			points_selected_net = []
			for_tests = nst_fli_arps_iths_dic[ii+1]
			for iiii in range(num_arp_net):
				point_selected_net = random.choice(points_range)
				for_tests = for_tests + points_selected_net
				while point_selected_net in for_tests:
					point_selected_net = random.choice(points_range)
				else:
					points_selected_net.append(point_selected_net)
			points_selected = nst_fli_arps_iths_dic[ii+1] + points_selected_net
			num_arp_iths = []
			for ijk in points_selected:
				num_arp_iths.append(ijk)
			#print ('before add nst_fli_arps_iths_dic[ii+1]:', nst_fli_arps_iths_dic[ii+1])
			points_selected.sort()
			points_selected.reverse()
			numarp_coords = []
			#print ('points_selected:', points_selected)
			for ith in points_selected:
				if ith in nst_fli_arps_iths_dic[ii+1]:
					xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli = E14_Coordinates_forArp (ith)
					for ith_iteration in range(len(nst_fli_arps_iths_dic[ii+1])):
						if nst_fli_arps_iths_dic[ii+1][ith_iteration]- ith == 0:
							xxx = 6*(ith_iteration)+0
					jjjjjjjj = 0
					for jj in range(len(xfli_starts)):
						#print ('jj:', len(xfli_starts), xxx, len(nst_fli_numarp_coords_dic[ii+1]))
						if abs(xfli_starts[jj] - nst_fli_numarp_coords_dic[ii+1][xxx]) <= 1e-3 and abs(xfli_ends[jj] - nst_fli_numarp_coords_dic[ii+1][xxx+3]) <= 1e-3:
							xfli_starts[jj] = xstart_daufli
							yfli_starts[jj] = ystart_daufli
							zfli_starts[jj] = zstart_daufli
							xfli_ends[jj] = xend_daufli
							yfli_ends[jj] = yend_daufli
							zfli_ends[jj] = zend_daufli
							numarp_coords = numarp_coords + [xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli]
							#print ('jjjjjjjjjjjjjjjjjjjjjjjj11111111111111111111111:', jjjjjjjj)
				else: # arp_num_count > nst_fli_numarp_dic[ii+1]
					xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli = E14_Coordinates_forArp (ith)
					free_end_distance = y_leading_edge_start- ystart_daufli
					if yend_daufli > ystart_daufli and free_end_distance > free_end_distance_critvalue:
						xfli_starts.append(xstart_daufli)
						yfli_starts.append(ystart_daufli)
						zfli_starts.append(zstart_daufli)
						xfli_ends.append(xend_daufli)
						yfli_ends.append(yend_daufli)
						zfli_ends.append(zend_daufli)
						ts_fli_s_dic[len(xfli_starts)] = t + 1
						ts_miss_fli_s_dic[len(xfli_starts)] = 0
						numarp_coords = numarp_coords + [xstart_daufli, ystart_daufli, zstart_daufli, xend_daufli, yend_daufli, zend_daufli]
						#print ('222222222222222222222222222222222222222222222')
					else:
						#print ('before remove', num_arp_iths)
						num_arp_iths.remove(ith)
						#print ('after remove', num_arp_iths, numarp_coords)
			nst_fli_numarp_dic[ii+1] = int(len(numarp_coords)/6.0)
			nst_fli_numarp_coords_dic[ii+1] = numarp_coords
			nst_fli_arps_iths_dic[ii+1] = num_arp_iths
			if nst_fli_numarp_dic[ii+1]!=len(nst_fli_arps_iths_dic[ii+1]):
				print (nst_fli_numarp_dic[ii+1], len(nst_fli_arps_iths_dic[ii+1]), num_arp_iths)
			#print (num_arp, 'good')
			#print (nst_fli_numarp_coords_dic[ii+1], 'good')
			for i in range(len(xfli_starts)):
				for j in range(len(xfli_starts)):
					llll=xfli_starts[i]-xfli_starts[j]
					mmmm=xfli_ends[i]-xfli_ends[j]
					if i != j and llll==0 and mmmm==0:
						#print (i, j)
						#print (xfli_starts[i], xfli_starts[j], xfli_ends[i], xfli_ends[j])
						#print (xfli_starts)
						quit()#   exit()
	#print ('This is the coordinates of the Arp23 Complex and the start point of the daughter filaments')
	return xfli_starts, yfli_starts, zfli_starts, xfli_ends, yfli_ends, zfli_ends, ts_fli_s_dic,ts_miss_fli_s_dic, nst_fli_numarp_dic, nst_fli_numarp_coords_dic, nst_fli_arps_iths_dic



# data of planes
z_min_low_plane, z_max_low_plane, z_min_central_plane, z_max_central_plane, y_central_plane, z_min_up_plane, z_max_up_plane, normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane, point_low_plane, point_central_plane, point_up_plane = E0_Parameters_Planes (y_leading_edge_start)
normalvectdic_planes, pointdic_planes = E1_NormalVector_Planes ()
# data of deformation
sita01to89_len0025to3000_load003to3_dleb0_dic = E2_Make_Datadic_sita01_89 ()
sita01to89_len0025to3000_load003to3_b0bxy01to09_dic = E3_Make_Datadic_sita01_89cds ()
# coordinates data of model
xmostart1, ymostart1, zmostart1, xmoend1, ymoend1, zmoend1, lenmo1= E4_Generate_Motherfilament (num_motherfilaments, mean_filamentlength, filamentlength_std_deviation, height_lamelip, y_low_start, y_up_start, xy_angle_mu, xy_angle_std_deviation, z_mu, z_std_deviation, z_mo_max_angle)
ts_fli_s_dic = {} # the start grwoth time of each filament
ts_miss_fli_s_dic = {} # the missing growth time of each filament
nst_fli_arps_iths_dic = {} # the iths of Arps generated on each filament
nst_fli_numarp_dic = {} # the number of arp2/3 complex generated on each filament
nst_fli_numarp_coords_dic = {} # the xyz coordinates of arp2/3 complex generated on each filament
for mo_num in range(len(xmostart1)):
	ts_mofli = 0
	ts_fli_s_dic[mo_num+1] = ts_mofli
	ts_miss_mofli = 0
	ts_miss_fli_s_dic[mo_num + 1] = ts_miss_mofli
for arp_num_allfli in range(10000):
	num_arp = 0
	nst_fli_numarp_dic[arp_num_allfli+1] = num_arp
	nst_fli_numarp_coords = []
	nst_fli_numarp_coords_dic[arp_num_allfli+1] = nst_fli_numarp_coords
	nst_fli_arps_iths = []
	nst_fli_arps_iths_dic[arp_num_allfli+1] = nst_fli_arps_iths
ts_fli_s = [] # the starting time of filament growth
xfli_starts = []
yfli_starts = []
zfli_starts = []
xfli_ends = []
yfli_ends = []
zfli_ends = []
xfli_starts = xfli_starts + xmostart1
yfli_starts = yfli_starts + ymostart1
zfli_starts = zfli_starts + zmostart1
xfli_ends = xfli_ends + xmoend1
yfli_ends = yfli_ends + ymoend1
zfli_ends = zfli_ends + zmoend1


p_overall_loads_times_dic = {}
pn_overall_loads_times_dic = {}
energy_overall_fls_times_dic = {}
k_meancurvatures_times_dic = {}
p_overall_loads_times = []
pn_overall_loads_times = []
energy_overall_fls_times = []
k_meancurvatures_times = []
times_moveforward = 0
time_moves = []
fli_density_y200_times = [] # this is the number of filament in the range of y<=100 from the leading edge

resisting_energy_up_limits = []
resisting_force_up_limits = []
for i in range(growth_time):
	if fluctuate_time_begin < i < fluctuate_time_end:
		#resisting_energy_up_limit = 2.0*num_motherfilaments*4.0e-19
		resisting_force_up_limit = membrane_tension_force + magnify_factor*extracellular_resistance + molecularclk_rupture_force
		#resisting_force_up_limit = 2.0*num_motherfilaments*10.0e-12
	else:
		#resisting_energy_up_limit = 1.0*num_motherfilaments*4.0e-19
		resisting_force_up_limit = membrane_tension_force + extracellular_resistance + molecularclk_rupture_force
		#resisting_force_up_limit = 1.0*num_motherfilaments*10.0e-12
	#resisting_energy_up_limits.append(resisting_energy_up_limit)
	resisting_force_up_limits.append(resisting_force_up_limit)
print (resisting_force_up_limits)
# all the initial force pn is 0
pn_loads_last_time = []
p_loads_last_time = []
energy_fls_last_time = []
k_meancurvatures_last_time = []
for ii in range (len(xfli_starts)):
	pn_initial_nucleation = 0
	pn_loads_last_time.append(pn_initial_nucleation)
	p_initial_nucleation = 0
	p_loads_last_time.append(p_initial_nucleation)
	energy_fl_last_time=0
	energy_fls_last_time.append(energy_fl_last_time)
	k_meancurvature_last_time=0
	k_meancurvatures_last_time.append(k_meancurvature_last_time)

actin_consumption_times=[]
noncap_fli_times=[]
fli_density_y200_times = [] # this is the number of filament in the range of y<=100 from the leading edge
fli_num_times = []
for t in range (growth_time):
	print ('growing time:', t+1)
	p_loads_time = []
	pn_loads_time = []
	energy_fls_time = []
	k_meancurvatures_time = []
	fli_density_count = 0
	actin_consumption_time = 0
	noncap_fli_time = 0
	fli_num_times.append(len(xfli_starts))
	for ii in range (len(xfli_starts)):
		xfli_start = xfli_starts[ii]
		yfli_start = yfli_starts[ii]
		zfli_start = zfli_starts[ii]
		xfli_end = xfli_ends[ii]
		yfli_end = yfli_ends[ii]
		zfli_end = zfli_ends[ii]
		if y_leading_edge_start - yfli_end <= 200:
			fli_density_count+=1
		fli_len_timemax, len_fli, xvector_fli, xori_fli_cos, yvector_fli, yori_fli_cos, zvector_fli, zori_fli_cos = E5_Vector_Motherfilament (xfli_start, yfli_start, zfli_start, xfli_end, yfli_end, zfli_end)
		sita_fli_planes_angles_dic = E6_Angle_Filaments_PlanesNorvect ()
		angle_yaxis_planesnormal_dic = E7_Angle_Yaxis_PlanesNorvect ()
		perpdistdic_fli_planes_dic = E8_PerpDist_Filament_Planes ()
		dist_fli_corespond_plane_dic, shortest_perpdist_plane, normal_vector_corespond_plane_dic = E9_Attach_Filament_Plane ()
		fli_corespplane, sita_fli_planej_angle, fli_len_timeplane, angle_yaxis_planenormal = E10_Fli_Angle_Dist_Corespplane ()
		x_fli_plane_end, y_fli_plane_end, z_fli_plane_end, xyz_fli_plane_end = E11_Pointattach_Filament_Plane ()
		len_critical = E12_Critical_Length ()
		#print (ii)
		#print (ts_fli_s_dic)
		#print (ts_fli_s_dic[ii+1])
		#############
		fli_len_time = growth_rate*(t + 1 - ts_fli_s_dic[ii+1]-ts_miss_fli_s_dic[ii+1])
		p_load_time, pn_load_time, energy_fl_time, k_meancurvature_time, fli_effective_len_time, load_corresp = E13_Load_Energy_Curvature_Length (ii)
		max_fil_length = int(fli_len_timemax / growth_rate) * growth_rate
		if fli_len_time < max_fil_length:
			noncap_fli_time = noncap_fli_time + 1
		if k_meancurvature_time ==0 and pn_load_time !=0:
			print('111111111111111111111111111111111111111')
		if k_meancurvature_time !=0 and pn_load_time ==0:
			print('222222222222222222222222222222222222222')
		# to polymerization the next actin monomer according to the interacting force between the barbed end and leading-edge membrane!! probability of polymerization = 1/(e**(alpha*pn))
		probability_exponent = alpha_pn * pn_load_time * (10 ** 12)
		if probability_exponent >10: # to delete the case that the exponent is too large the make "OverflowError: (34, 'Result too large')"
			probability_exponent =10
		denominator_probability = euler_number**(probability_exponent)
		zero_number = int(denominator_probability)-1
		if zero_number >= critical_zero_number: # that is pn_load_time>=25e-12N
			actin_polymerization = 0
		else:
			zeros_number=[]
			for i_prob in range(zero_number):
				zeros_number=zeros_number+[0]
			possibility_miss_actin = zeros_number+[1]
			actin_polymerization = random.choice(possibility_miss_actin)
		if actin_polymerization == 0:
			ts_miss_fli_s_dic[ii + 1] = ts_miss_fli_s_dic[ii + 1]+1 ##to delete the actin monomer adding
			#print ('hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh:',ii, len(pn_loads_last_time))
			pn_load_time = pn_loads_last_time[ii] #to delete the excessive large force
			p_load_time = p_loads_last_time[ii]
			energy_fl_time = energy_fls_last_time[ii]
			k_meancurvature_time = k_meancurvatures_last_time[ii]
		else: # to calculate the actin monomer consumption
			if fli_len_time < max_fil_length:
				actin_consumption_time = actin_consumption_time+1
		#print (pn_load_time, ts_miss_fli_s_dic)
		xfli_starts, yfli_starts, zfli_starts, xfli_ends, yfli_ends, zfli_ends, ts_fli_s_dic,ts_miss_fli_s_dic, nst_fli_numarp_dic, nst_fli_numarp_coords_dic, nst_fli_arps_iths_dic = E15_Arp_Generation (ts_fli_s_dic,ts_miss_fli_s_dic, nst_fli_numarp_dic, nst_fli_numarp_coords_dic, nst_fli_arps_iths_dic)
		#print ('this is the dictionary of filaments and their coresponding number of arp2/3 complex1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111')
		#print (len(nst_fli_numarp_dic))
		#print (nst_fli_numarp_dic)
		p_loads_time.append(p_load_time)
		pn_loads_time.append(pn_load_time)
		energy_fls_time.append(energy_fl_time)
		k_meancurvatures_time.append(k_meancurvature_time)
	pn_loads_last_time = pn_loads_time
	p_loads_last_time = p_loads_time
	energy_fls_last_time = energy_fls_time
	k_meancurvatures_last_time = k_meancurvatures_time
	fli_density_y200_times.append(fli_density_count)
	p_overall_loads_time = np.sum(p_loads_time)
	pn_overall_loads_time = np.sum(pn_loads_time)
	energy_overall_fls_time = np.sum(energy_fls_time)
	p_overall_loads_times_dic[t+1] = p_overall_loads_time
	pn_overall_loads_times_dic[t+1] = pn_overall_loads_time
	energy_overall_fls_times_dic[t+1] = energy_overall_fls_time
	k_meancurvatures_times_dic[t+1] = k_meancurvatures_time
	p_overall_loads_times.append(p_overall_loads_time)
	pn_overall_loads_times.append(pn_overall_loads_time)
	energy_overall_fls_times.append(energy_overall_fls_time)
	k_meancurvatures_times.append(k_meancurvatures_time)
	actin_consumption_times.append(actin_consumption_time)
	noncap_fli_times.append(noncap_fli_time)
	#print (p_overall_loads_times)
	#print (pn_overall_loads_times)
	#print (energy_overall_fls_times)
	#print (k_meancurvatures_times[-1])
	#forward_strain_time = pn_overall_loads_time / (area_normal * E_extracematrix)
	#forward_displancement = forward_strain_time * forward_len_influenced_extracellular
	#y_leading_edge_start = y_leading_edge_start + forward_displancement
	#z_min_low_plane, z_max_low_plane, z_min_central_plane, z_max_central_plane, y_central_plane, z_min_up_plane, z_max_up_plane, normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane, point_low_plane, point_central_plane, point_up_plane = E0_Parameters_Planes (y_leading_edge_start)
	#normalvectdic_planes, pointdic_planes = E1_NormalVector_Planes ()
	#if energy_overall_fls_time > resisting_energy_up_limits[t]: # energy_overall_fls_time > extracellular_energy + energy_barrier
		#times_moveforward = times_moveforward + 1
		#time_move = t + 1
		#time_moves.append(time_move)
		#y_leading_edge_start = y_leading_edge_start + step_size
		#print ('This is the ' + str(times_moveforward) + 'st ' + 'time that the leading membrane edge is pushed forward with step size of 10nm at the time of ' + str(time_move) + 'ms')
		#z_min_low_plane, z_max_low_plane, z_min_central_plane, z_max_central_plane, y_central_plane, z_min_up_plane, z_max_up_plane, normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane, point_low_plane, point_central_plane, point_up_plane = E0_Parameters_Planes (y_leading_edge_start)
		#normalvectdic_planes, pointdic_planes = E1_NormalVector_Planes ()
	# polymerization force of branched actin filament pushes the leading edge membrane to overcome the ECM resistance and migration forward
	if pn_overall_loads_time > resisting_force_up_limits[t]: #resisting_force_up_limits[t]: # energy_overall_fls_time > extracellular_energy + energy_barrier
		times_moveforward = times_moveforward + 1
		time_move = t + 1
		time_moves.append(time_move)
		y_leading_edge_start = y_leading_edge_start + step_size
		#print ('This is the ' + str(times_moveforward) + 'st ' + 'time that the leading membrane edge is pushed forward with step size of 10nm at the time of ' + str(time_move) + 'ms')
		z_min_low_plane, z_max_low_plane, z_min_central_plane, z_max_central_plane, y_central_plane, z_min_up_plane, z_max_up_plane, normal_vect_low_plane, normal_vect_central_plane, normal_vect_up_plane, point_low_plane, point_central_plane, point_up_plane = E0_Parameters_Planes (y_leading_edge_start)
		normalvectdic_planes, pointdic_planes = E1_NormalVector_Planes ()
max_p = p_overall_loads_times.index(max(p_overall_loads_times))
max_pn = pn_overall_loads_times.index(max(pn_overall_loads_times))
max_energy = energy_overall_fls_times.index(max(energy_overall_fls_times))
#print (p_overall_loads_times[max_p])
#print (pn_overall_loads_times[max_pn])
#print (energy_overall_fls_times[max_energy])

# To extract the front len(xfli_starts) elements from the dictionary of nst_fli_numarp_dic. These elements are the real number of filaments generated in the model
fli_keys = [i for i in nst_fli_numarp_dic.keys()][:len(xfli_starts)]
fli_values = [i for i in nst_fli_numarp_dic.values()][:len(xfli_starts)]
nth_fli_numarp_dic = {}
for i in range(len(fli_keys)):
	fli_key = fli_keys[i]
	fli_value = fli_values[i]
	nth_fli_numarp_dic[fli_key] = fli_value
print (nth_fli_numarp_dic)
print (ts_fli_s_dic)
print (len(xfli_starts))
times_flis_k_meancurvature_dic = {}
times_curved_numfli_dic = {} #this is dictonary form of the number of filaments that attaching the leading edge membrane at every time
times_curved_numfli = [] #this is list form of the number of filaments that attaching the leading edge membrane at every time
times_all_meancurvature = []
for i in range(len(k_meancurvatures_times)):
	time_flis_k_meancurvature_dic = {}
	count_curved_numfli = 0
	sum_meancurvature = 0
	for j in range(len(k_meancurvatures_times[i])):
		time_fli_k_meancurvature = k_meancurvatures_times[i][j]
		time_flis_k_meancurvature_dic[j+1] = time_fli_k_meancurvature
		if k_meancurvatures_times[i][j] > 0:
			count_curved_numfli+=1
			sum_meancurvature = sum_meancurvature + k_meancurvatures_times[i][j]
	if count_curved_numfli == 0:
		time_all_meancurvature =0
	else:
		time_all_meancurvature = sum_meancurvature / count_curved_numfli
	time_flis_k_meancurvature_dic[i+1] = time_flis_k_meancurvature_dic
	times_curved_numfli_dic[i+1] = count_curved_numfli
	times_curved_numfli.append(count_curved_numfli)
	times_all_meancurvature.append(time_all_meancurvature)
print (times_curved_numfli_dic)
#print (times_curved_numfli)
#print (y_leading_edge_start)
#print (time_moves)
#print (times_curved_numfli)
#print (pn_overall_loads_times)
#print (energy_overall_fls_times)
#print (len(times_curved_numfli))
#print (len(pn_overall_loads_times))
#print (len(energy_overall_fls_times))
#print (len(fli_density_y200_times))
"""
# to extract pn at the last time
pns_last_time=[]
for i in range (len(k_meancurvatures_times[-1])):
	if len(k_meancurvatures_times[-1][i]) > 0:

"""



"""
print (fli_density_y200_times)
file1=open('pn_overall_loads_times_case1','w')
file1.write(str(pn_overall_loads_times));
file1.close()
file2=open('energy_overall_fls_times_case1','w')
file2.write(str(energy_overall_fls_times));
file2.close()
"""
sheet.write(1, 1, 'time')
sheet.write(1, 2, 'attaching_filament')
sheet.write(1, 3, 'noncap_filaments')
sheet.write(1, 4, 'pn force')
sheet.write(1, 5, 'deformation energy')
sheet.write(1, 10, 'all meancurvature')
sheet.write(1, 11, 'actin consumption')
sheet.write(1, 6, 'veloctiy_timeframe')
sheet.write(1, 7, 'fli_time')
sheet.write(1, 8, 'time_move')
sheet.write(1, 9, 'ycoord_leading_edge_start')
sheet.write(2, 8, 0)
sheet.write(2, 9, y_leading_edge_start_time0)
sheet.write(1, 12, 'fil_number')
sheet.write(1, 13, 'fil_pn')
for i in range(len(times_curved_numfli)):
	row_num = i+2
	time_at = (i+1)*growth_rate
	sheet.write(row_num, 1, time_at)
	filament_num = times_curved_numfli[i]
	sheet.write(row_num, 2, filament_num)
	noncap_fli_time = noncap_fli_times[i]
	sheet.write(row_num, 3, noncap_fli_time)
	pn_force = pn_overall_loads_times[i]+0.0
	sheet.write(row_num, 4, pn_force)
	energy_deform = energy_overall_fls_times[i]+0.0
	sheet.write(row_num, 5, energy_deform)
	fli_num_time = fli_num_times[i]
	sheet.write(row_num, 7, fli_num_time)
	meancurvature_time = times_all_meancurvature[i] + 0.0
	sheet.write(row_num, 10, meancurvature_time)
	actin_consumption_time = actin_consumption_times[i]
	sheet.write(row_num, 11, actin_consumption_time)
y_leading_edge_start_times = []
for i in range(len(time_moves)):
	row_num = i+3
	at_time_move = time_moves[i]
	sheet.write(row_num, 8, at_time_move)
	ycoord = y_leading_edge_start_time0 + (i+1)*step_size
	sheet.write(row_num, 9, ycoord)
	y_leading_edge_start_times.append(ycoord)
# to output the pn force of each filament at the final time
for i in range (len(pn_loads_time)):
	row_num = i + 2
	sheet.write(row_num, 12, i+1)
	pn_fil_time =pn_loads_time[i]+0.0
	sheet.write(row_num, 13, pn_fil_time)
y_leading_edge_start_alltimes = [y_leading_edge_start_time0] + y_leading_edge_start_times
alltime_moves = [0] + time_moves
velocity_timeframes = []
for i in range(len(y_leading_edge_start_alltimes)-1):
	displacement_timeframe = y_leading_edge_start_alltimes[i+1] - y_leading_edge_start_alltimes[i]
	time_cost = alltime_moves[i+1] - alltime_moves[i]
	velocity_timeframe = displacement_timeframe/time_cost/growth_rate
	velocity_timeframes.append(velocity_timeframe)
velocity_everytimes = []
for i in range(growth_time):
	at_time = i + 1
	for j in range(len(alltime_moves)-1):
		if alltime_moves[j]<= at_time < alltime_moves[j+1]:
			velocity_everytime = velocity_timeframes[j]
			velocity_everytimes.append(velocity_everytime)
			row_num = i+2
			sheet.write(row_num, 6, velocity_everytime)

xls.save(excel_savepath)



angles_fli_yaxis = []
def Angle_Yaxis_XYplane ():
	for i in range(len(xfli_starts)):
		xfli_vector = xfli_ends[i] - xfli_starts[i]
		yfli_vector = yfli_ends[i] - yfli_starts[i]
		zfli_vector = 0
		fli_len_xyplane = (xfli_vector**2 + yfli_vector**2 + zfli_vector**2)**0.5
		yaxis_xvector = 0
		yaxis_yvector = 1
		yaxis_zvector = 0
		yaxis_unitlen = (yaxis_xvector**2 + yaxis_yvector**2 + yaxis_zvector**2)**0.5
		if xfli_vector >= 0:
			angle_with_yaxis = math.acos((yaxis_xvector*xfli_vector + yaxis_yvector*yfli_vector + yaxis_zvector*zfli_vector)/(fli_len_xyplane*yaxis_unitlen))*180/np.pi
		else:
			angle_with_yaxis = -math.acos((yaxis_xvector*xfli_vector + yaxis_yvector*yfli_vector + yaxis_zvector*zfli_vector)/(fli_len_xyplane*yaxis_unitlen))*180/np.pi
		angle_with_yaxis = round(angle_with_yaxis, 2)
		angles_fli_yaxis.append(angle_with_yaxis)
	return angles_fli_yaxis

"""
angles_fli_yaxis = Angle_Yaxis_XYplane ()
file3=open('angles_fli_yaxis_section3case2','w')
file3.write(str(angles_fli_yaxis));
file3.close()
"""


print (pn_loads_time)
print (y_leading_edge_start)
print (yfli_starts)







