﻿#!/usr/bin/python

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
This  is  the  code  to simulate the relationships of the compressive force, deformation energy and end angle againt the
	compressive strain of an inclined and initially straight actin filament which is compressed by a rigid membrane plane. 
				 Bending, axial compression and transverse shear are considered. 
			Friction between the end of the actin filament and the rigid membrane is ignored.

	 The inclined actin filament is assumed to have a length L0 and a circular cross-section of diameter d0

	Sita is the angle between the vertical axis and the initial undeformed actin filament in the deformation plane

					 Aspect ratio:  L0/d0,  nu -- Poisson's ratio of the solid material

					   OUTPUTS: 'Displacement/L0    P/(EI/L0^2)   U/(EI/L0)   beta'
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

from numpy import*
import random
import numpy as np
from sympy import *
import os
import re

pi = 3.1415927
sita = 1
dsita = 1

l_0 = 1.0
n_segments = 100000
ds = l_0 / n_segments

growth_rate = 5
max_length = 300
steps_increase = int(max_length/growth_rate)
diameter = 7
poisson_ratio = 0.3


dp = 0.03    # the derivative load
n_dps = 100   # to devide the load p into 100 parts: dp

p_array = []

calc_accuracy = 0.000000001
cir_for_accuracy = 30

beta0_1st_list = []
beta0_1st_array = []

deform_normal_list = []
deform_normal_array = []

u_total_list = []
u_total_array = []

sita_array = []
length_arrary = []

dleb0 = []
dleb0_lengths = []
dleb0_lengths_sitas = []

output_name = ["Displacement/L0", "P/(EI/L0^2)", "U/(EI/L0)", "beta"]


sita_s = []
while sita <= 90:
	dleb0_lengths = []
	sita_s.append(sita)
	beta0_s = []
	beta_s = []
	for i in range(n_segments+1):
		beta0 = sita
		beta0_s.append(beta0)
		beta = beta0
		beta_s.append(beta)
	l_0s = []
	ld_ratios = []
	for i in range(steps_increase):
		dleb0 = []
		l_time = (i+1) * growth_rate
		l_0s.append(l_time)
		ld_ratio = l_time / diameter
		ld_ratios.append(ld_ratio)
		coef_comp_vs_bend = 1.0 / (16 * (ld_ratio ** 2))
		print (ld_ratio)
		p = 0.0
		file = open("list_tutorial", "w")
		file.write(str(output_name[0]) + "          " + str(output_name[1]) + "    " + str(output_name[2]) + "   " + str(output_name[3]) + "\n")
		p_list = []
		dleb0_loads = []
		for l in range(n_dps):
			p = p + dp
			p_list.append(p)
			m = 0
			while m < cir_for_accuracy:
				c1_y = 0.0
				c1_doubinteg = 0.0
				for n in range(n_segments):
					l_ratio_aft_comp = 1.0 - p * coef_comp_vs_bend * math.cos(math.radians(beta0_s[n]))
					c1_y = c1_y + math.sin(math.radians(beta0_s[n])) * ds * l_ratio_aft_comp
					c1_doubinteg = c1_doubinteg + c1_y * ds * l_ratio_aft_comp
				c2_y = 0.0
				c2_doubinteg = 0.0
				c_calculated_biggest_dif = 0.0
				coef_shear_vs_bend = (20.0 * (1 + poisson_ratio) / 9.0) * p * coef_comp_vs_bend
				for k in range(n_segments):
					l_ratio_aft_comp = 1.0 - p * coef_comp_vs_bend * math.cos(math.radians(beta0_s[k]))
					c2_y = c2_y + math.sin(math.radians(beta0_s[k])) * ds * l_ratio_aft_comp
					c2_doubinteg = c2_doubinteg + c2_y * ds * l_ratio_aft_comp
					beta_s[k] = (math.radians(sita)+p*(c1_doubinteg - c2_doubinteg)+coef_shear_vs_bend*math.sin(math.radians(beta0_s[k])))*180/pi
					beta0_s[k] = beta0_s[k] + (beta_s[k] - beta0_s[k])/2.0
					c7 = abs(beta_s[k] - beta0_s[k])
					if c7 >= c_calculated_biggest_dif:
						c_calculated_biggest_dif = c7
				if c_calculated_biggest_dif <= calc_accuracy:
					m = cir_for_accuracy
				else:
					m=m+1
			beta0_1st = beta0_s[0]
			beta0_1st_list.append(beta0_1st)
			c3_y = 0.0
			height_normal = 0.0
			u_bend = 0.0 # bending deformation energy
			u_comp = 0.0 # compression deformation energy
			u_shear = 0.0 # shearing deformation energy
			u_total = 0.0 # total deformation energy
			for j in range(n_segments ):
				l_ratio_aft_comp = 1.0 - p * coef_comp_vs_bend * math.cos(math.radians(beta0_s[j]))
				height_normal = height_normal + math.cos(math.radians(beta0_s[j])) * ds * l_ratio_aft_comp
				print (beta0_s[j])
				c3_y = c3_y + math.sin(math.radians(beta0_s[j])) * ds * l_ratio_aft_comp
				u_bend = u_bend + p * c3_y * (math.radians(beta0_s[j])-math.radians(beta0_s[j+1]))/2
				u_comp = u_comp + coef_comp_vs_bend * (p**2) * (math.cos(math.radians(beta0_s[j]))**2) * ds/2
				u_shear = u_shear + 10 * coef_comp_vs_bend * (1 + poisson_ratio) * (p**2) * (math.sin(math.radians(beta0_s[j]))**2) * ds/9
				u_total = u_bend + u_comp + u_shear
			print (height_normal)
			deform_normal = l_0 * math.cos(math.radians(sita)) - height_normal
			print (deform_normal)
			deform_normal_list.append(deform_normal)
			u_total_list.append(u_total)
			deform_normal_decim11 = round(deform_normal, 11)
			p_decim8 = round(p, 8)
			u_total_decim8 = round(u_total, 8)
			beta0_1st_decim8 = round(beta0_1st, 8)
			dleb0_load = [deform_normal_decim11, p_decim8, u_total_decim8, beta0_1st_decim8]
			file.write(str(dleb0_load[0]) + "            " + str(dleb0_load[1]) + "            " + str(dleb0_load[2]) + "            " + str(dleb0_load[3]) + "\n")
			dleb0_loads.append(dleb0_load)
			if sita < 10:
				namesita = str(0) + str(sita)
			else:
				namesita = str(sita)
			if l_time < 10:
				namelength = str(0) + str(0) + str(l_time)
			elif 10 <= l_time < 100:
				namelength = str(0) + str(l_time)
			else:
				namelength = str(l_time)
			name_sita_length = str(namesita) + str(namelength)
			filename = name_sita_length
			file0 = open(filename, "w")
			file0.write(str(dleb0_loads))
			file0.close()
		dleb0_lengths.append(dleb0_loads)
	dleb0_lengths_sitas.append(dleb0_lengths)
	sita = sita + dsita


print (len(dleb0_lengths))
print (len(dleb0_lengths_sitas))

file1=open('dleb0-lengths','w')
file1.write(str(dleb0_lengths));
file1.close()

file2=open('dleb0-lengths-sitas','w')
file2.write(str(dleb0_lengths_sitas));
file2.close()


